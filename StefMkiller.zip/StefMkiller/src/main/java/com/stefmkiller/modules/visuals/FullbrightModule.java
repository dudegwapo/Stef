package com.stefmkiller.modules.visuals;

import com.stefmkiller.modules.Category;
import com.stefmkiller.modules.Module;

public class FullbrightModule extends Module {
    private double oldGamma = 1.0;

    public FullbrightModule() {
        super("Fullbright", "Enhances world brightness for absolute night visibility.", Category.VISUALS);
    }

    @Override
    public void onEnable() {
        if (mc.options != null) {
            oldGamma = mc.options.getGamma().getValue();
            mc.options.getGamma().setValue(16.0);
        }
    }

    @Override
    public void onDisable() {
        if (mc.options != null) {
            mc.options.getGamma().setValue(oldGamma);
        }
    }
}
