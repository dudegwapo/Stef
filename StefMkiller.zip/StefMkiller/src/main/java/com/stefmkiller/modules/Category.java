package com.stefmkiller.modules;

public enum Category {
    VISUALS("Visuals"),
    AUTOMATION("Automation"),
    WORLD("World Tools"),
    PLAYER("Player Tools"),
    INVENTORY("Inventory Tools"),
    WORLD_INFO("World Information");

    private final String displayName;

    Category(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
