package com.stefmkiller.utils;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class KeybindManager {
    public static KeyBinding guiKeyBinding;

    public static void registerKeys() {
        guiKeyBinding = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.stefmkiller.gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.stefmkiller.main"
        ));
    }
}
