package com.stefmkiller.gui;

import com.stefmkiller.core.ModuleManager;
import com.stefmkiller.modules.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class StefMkillerScreen extends Screen {
    public StefMkillerScreen() {
        super(Text.literal("StefMkiller Command Center"));
    }

    @Override
    protected void init() {
        super.init();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 20, 0xFFFFFF);

        int yOffset = 50;
        for (Module module : ModuleManager.getModules()) {
            String status = module.getName() + " [" + (module.isEnabled() ? "§aON" : "§cOFF") + "]";
            context.drawTextWithShadow(this.textRenderer, status, 40, yOffset, 0xFFFFFF);
            yOffset += 20;
        }

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return true;
    }
}
