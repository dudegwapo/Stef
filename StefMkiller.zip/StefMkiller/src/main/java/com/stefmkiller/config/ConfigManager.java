package com.stefmkiller.config;

import com.stefmkiller.core.ModuleManager;
import com.stefmkiller.modules.Module;
import net.fabricmc.loader.api.FabricLoader;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Properties;

public class ConfigManager {
    private static final File CONFIG_FILE = FabricLoader.getInstance().getConfigDir().resolve("stefmkiller.properties").toFile();

    public static void saveConfig() {
        Properties props = new Properties();
        for (Module m : ModuleManager.getModules()) {
            props.setProperty(m.getName(), Boolean.toString(m.isEnabled()));
        }
        try (FileWriter writer = new FileWriter(CONFIG_FILE)) {
            props.store(writer, "StefMkiller Configuration");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void loadConfig() {
        if (!CONFIG_FILE.exists()) return;
        Properties props = new Properties();
        try {
            props.load(Files.newInputStream(CONFIG_FILE.toPath()));
            for (Module m : ModuleManager.getModules()) {
                String val = props.getProperty(m.getName());
                if (val != null) {
                    m.setEnabled(Boolean.parseBoolean(val));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
