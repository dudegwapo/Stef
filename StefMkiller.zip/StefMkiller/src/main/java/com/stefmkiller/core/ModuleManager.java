package com.stefmkiller.core;

import com.stefmkiller.modules.Module;
import com.stefmkiller.modules.visuals.FullbrightModule;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    private static final List<Module> modules = new ArrayList<>();

    public static void init() {
        modules.add(new FullbrightModule());
    }

    public static List<Module> getModules() {
        return modules;
    }

    public static void onTick() {
        for (Module module : modules) {
            if (module.isEnabled()) {
                module.onTick();
            }
        }
    }
}
