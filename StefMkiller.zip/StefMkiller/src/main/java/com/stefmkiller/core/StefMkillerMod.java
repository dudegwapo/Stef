package com.stefmkiller.core;

import com.stefmkiller.config.ConfigManager;
import com.stefmkiller.gui.StefMkillerScreen;
import com.stefmkiller.utils.KeybindManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

public class StefMkillerMod implements ClientModInitializer {
    public static final String MOD_ID = "stefmkiller";

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        KeybindManager.registerKeys();
        ConfigManager.loadConfig();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            ModuleManager.onTick();

            if (KeybindManager.guiKeyBinding.wasPressed()) {
                client.setScreen(new StefMkillerScreen());
            }
        });

        Runtime.getRuntime().addShutdownHook(new Thread(ConfigManager::saveConfig));
    }
}
